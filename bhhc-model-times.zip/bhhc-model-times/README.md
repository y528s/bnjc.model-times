# BHHC model times

Estimated Brighton & Hove Hebrew Congregation service times, so BNJC can prepare the shul and keep the space free before BHHC publishes its weekly Orders. The confirmed Orders, sent each Monday after the Rabbi has checked them, always override these estimates.

Live page: https://bnjc.github.io/bhhc-model-times/

## How it works
- Candle lighting, Shabbat ends and fast ends come from Hebcal for Brighton: 18 min before sunset, nightfall at 8.5°, and fasts ending at 6°.
- Service times are set relative to those (see "How the times are worked out" on the page), with a back-test against published BHHC times.

## Rebuild (e.g. to extend the date range)
```
npm install
npm run build
```
Edit the date range and rules in `scripts/gen.mjs`, and the page in `scripts/page.tpl.html`.
