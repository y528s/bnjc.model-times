import {Location, Zmanim, HDate, HebrewCalendar, flags} from '@hebcal/core';
import fs from 'fs';
const LOC = new Location(50.82838,-0.13947,false,'Europe/London','Brighton','GB');
const TZ='Europe/London';
const rnd = d => new Date(Math.round(d.getTime()/60000)*60000);
const min = d => { const p=new Intl.DateTimeFormat('en-GB',{timeZone:TZ,hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(d); return (+p.find(x=>x.type==='hour').value)*60 + (+p.find(x=>x.type==='minute').value); };
const fmt = m => { if (m==null) return ''; const h=Math.floor(m/60), mm=m%60; const h12=((h+11)%12)+1; return `${h12}.${String(mm).padStart(2,'0')} ${h<12?'am':'pm'}`; };
const floor5 = m => Math.floor(m/5)*5;
const z = d => new Zmanim(LOC, d, false);
const sunset = d => min(rnd(z(d).sunset()));
const cl = d => sunset(d)-18; // approx; recompute precisely
const clExact = d => min(rnd(new Date(z(d).sunset().getTime()-18*60000)));
const end85 = d => min(rnd(z(d).tzeit(8.5)));
const end6 = d => min(rnd(z(d).tzeit(6)));
const iso = d => d.toISOString().slice(0,10);
const isBST = d => { const o=new Intl.DateTimeFormat('en-GB',{timeZone:TZ,timeZoneName:'short'}).format(d); return o.includes('BST'); };

// holiday lookup
const evs = HebrewCalendar.calendar({start:new Date(2026,9,18),end:new Date(2026,11,31),location:LOC,il:false,sedrot:true,candlelighting:false,shabbatMevarchim:true});
const byDay = {};
const lk = g => `${g.getFullYear()}-${String(g.getMonth()+1).padStart(2,'0')}-${String(g.getDate()).padStart(2,'0')}`;
for (const e of evs) { const k=lk(e.getDate().greg()); (byDay[k] ||= []).push(e); }
const bankHols = {'2026-12-25':'Christmas Day (bank holiday)','2026-12-28':'Boxing Day substitute (bank holiday)'};
const rows=[];
const add = (d, occ, service, m, conf, basis, alt='', status='Predicted') => rows.push({date:iso(d), dow:d.toLocaleDateString('en-GB',{weekday:'short',timeZone:'UTC'}), heb:new HDate(d).render('en',false), occ, service, time:fmt(m), mins:m, conf, basis, alt, status});

for (let t=Date.UTC(2026,9,18,12); t<=Date.UTC(2026,11,31,12); t+=86400000) {
  const d = new Date(t); const k=iso(d); const dow=d.getUTCDay();
  const es = byDay[k]||[];
  const names = es.map(e=>e.render('en')).filter(n=>!/^Parashat|Chag HaBanot|Sigd|Fast (begins|ends)|Candle|Mevarchim/.test(n));
  const parsha = es.find(e=>e.getFlags()&flags.PARSHA_HASHAVUA);
  const rc = es.some(e=>e.getFlags()&flags.ROSH_CHODESH);
  const prevK = iso(new Date(t-86400000)); const chan = (byDay[prevK]||[]).some(e=>/Chanukah: \d+ Candle/.test(e.render('en'))) || es.some(e=>/8th Day/.test(e.render('en')));
  const fast = es.find(e=>e.getFlags()&flags.MINOR_FAST);
  const mev = es.some(e=>e.getFlags()&flags.SHABBAT_MEVARCHIM);
  let occ = [];
  if (parsha) occ.push(parsha.render('en').replace(/^Parashat /,'Shabbat '));
  if (dow===5) { const nx=(byDay[iso(new Date(t+86400000))]||[]).find(e=>e.getFlags()&flags.PARSHA_HASHAVUA); if (nx) occ.push(nx.render('en').replace(/^Parashat /,'Erev Shabbat ')); }
  occ.push(...names.filter(n=>!/Candles/.test(n)));
  if (es.some(e=>/Chanukah: \d+ Candle/.test(e.render('en')))) occ.push('Light '+es.find(e=>/Chanukah: \d+ Candle/.test(e.render('en'))).render('en').replace('Chanukah: ','').replace(/Candles?/,m=>m.toLowerCase())+' tonight');
  if (chan && !occ.some(o=>/Chanukah: 8th/.test(o))) occ.push(dow===6?'Shabbat Chanukah':'Chanukah'); if (k==='2026-12-04') occ.push('Erev Chanukah');
  if (bankHols[k]) occ.push(bankHols[k]);
  if (mev) occ.push('Shabbat Mevarchim');
  if (k==='2026-10-25') occ.push('Clocks go back');
  occ.sort((a,b)=>(/^Light /.test(a))-(/^Light /.test(b)));
  const occS = [...new Set(occ.map(o=>o.replace('Chanukah: 8th Day','Chanukah, 8th day')))].join(' · ');
  const published = k<='2026-10-23';
  const P = published ? 'Published' : 'Predicted';
  if (dow===6) {
    const gmt = !isBST(d);
    const shach = gmt ? 9*60+15 : 9*60+30;
    add(d,occS,'Twenty Minutes of Torah',shach-30, gmt?'Medium':'High','30 min before Shacharit (seen 14 Mar and 17 Oct)', gmt?'9.00 am if Shacharit stays 9.30':'');
    add(d,occS,'Shacharit',shach, gmt?'Medium':'High', gmt?'9.15 am in GMT months (14 Mar); 9.30 am in BST months (Sep–Oct)':'9.30 am every BST Shabbat seen', gmt?'9.30 am':'');
    const e = end85(d); const mm = floor5(e-80);
    add(d,occS,'Shiur in Hilchot Shabbat',mm-30,'Low','Held 30 min before Mincha on 17 Oct; not on every sheet','May not run');
    add(d,occS,'Mincha, then Seudah Shlishit',mm,'Medium','Shabbat ends minus 80 min, rounded down to 5 min (3 of 4 exact)','+5 min');
    add(d,occS,'Maariv & Shabbat ends',e,'High','Hebcal Brighton nightfall (8.5°), 11 of 11 exact');
  } else {
    // morning
    let sh, conf='High', basis, alt='';
    if (fast) { sh = (dow===0? 8*60+30 : 7*60+30) - 30; conf='Medium'; basis='Fast day: 30 min earlier than usual (Fast of Gedaliah Mon 7.00; Erev YK Sun 8.00)'; alt=dow===0?'8.30 am':'7.30 am'; }
    else if (bankHols[k]) { sh = 8*60+30; conf='Low'; basis='Bank holiday: assumed Sunday time (no BHHC example yet)'; alt='7.30 am'; }
    else if (dow===0) { sh = 8*60+30; basis='Sunday 8.30 am on every sheet and the website'; }
    else { sh = 7*60+30; basis='Mon–Fri 7.30 am on every sheet and the website'; }
    if (!fast && (rc||chan) && dow!==0) { conf='Medium'; basis += '; Rosh Chodesh/Chanukah may start a little earlier for Hallel'; alt='7.15 am'; }
    if (!fast && (rc||chan) && dow===0) { conf='Medium'; basis += '; Chanukah adds Hallel'; alt='8.15 am'; }
    add(d,occS, fast?'Selichot & Shacharit':'Shacharit', sh, published&&!fast?'Published':conf, basis, alt, P);
    if (fast) {
      const fe = end6(d);
      add(d,occS,'Fast begins',min(rnd(z(d).alotHaShachar())),'High','Hebcal dawn (16.1°)');
      add(d,occS,'Mincha & Maariv',floor5(fe-65),'Medium','Fast ends minus 65 min, rounded down (Gedaliah: 6.45 pm for 7.51 pm end)','');
      add(d,occS,'Fast ends',fe,'High','Hebcal Brighton 6° nightfall (Gedaliah and Tisha B’Av within 1 min)');
    } else if (dow===5) {
      const c = clExact(d);
      add(d,occS,'Candle lighting',c,'High','Hebcal Brighton: 18 min before sunset (8 of 8 exact)');
      add(d,occS,'Mincha & Kabbalat Shabbat',c,'High','Same as candle lighting (5 of 6 exact; once rounded to 6.00)','Up to 5 min earlier');
    } else {
      const bst = isBST(d);
      add(d,occS,'Mincha & Maariv',17*60+30, published?'Published':(bst?'High':'Low'), published?'On the 17 Oct sheet for Sun–Thu':(bst?'5.30 pm, as on the 17 Oct sheet':'5.30 pm on the Oct and March sheets; no winter (GMT) sheet seen yet'), bst||published?'':`About ${fmt(floor5(sunset(d)-15))} if they switch to before sunset`, P);
    }
  }
}
// fix status for published Shabbat-week items
for (const r of rows) { if (r.status==='Published') r.conf='Published'; }
// back-test
const D = s=>new Date(s+'T12:00:00Z');
const bt = [];
const T = (s,label,rule,pred,act,src) => bt.push({date:s,label,rule,pred:fmt(pred),act,diff:null,src,predM:pred});
const pm=(s)=>{const [h,m]=s.split('.').map(Number);return null};
const obsCL=[['2026-03-13','5.44 pm','BHHC website'],['2026-09-11','7.06 pm','High Holiday sheet'],['2026-09-18','6.50 pm','High Holiday sheet'],['2026-09-20','6.45 pm','High Holiday sheet'],['2026-09-25','6.34 pm','High Holiday sheet'],['2026-10-02','6.19 pm','High Holiday sheet'],['2026-10-09','6.03 pm','High Holiday sheet'],['2026-10-16','5.48 pm','Weekly sheet 17 Oct']];
for (const [s,a,src] of obsCL) T(s,'Candle lighting','18 min before sunset',clExact(D(s)),a,src);
const obsEnd=[['2026-03-14','6.52 pm','BHHC website'],['2026-09-12','8.11 pm','HH sheet (candles after)'],['2026-09-13','8.09 pm','HH sheet'],['2026-09-19','7.55 pm','HH sheet'],['2026-09-21','7.50 pm','HH sheet (Yom Kippur)'],['2026-09-26','7.39 pm','HH sheet (candles after)'],['2026-09-27','7.36 pm','HH sheet'],['2026-10-03','7.23 pm','HH sheet (candles after)'],['2026-10-04','7.21 pm','HH sheet'],['2026-10-10','7.08 pm','HH sheet'],['2026-10-17','6.53 pm','Weekly sheet 17 Oct']];
for (const [s,a,src] of obsEnd) T(s,'Shabbat / Yom Tov ends','Nightfall, sun 8.5° below horizon',end85(D(s)),a,src);
for (const [s,a,src] of [['2026-09-14','7.51 pm','HH sheet (Fast of Gedaliah)'],['2026-07-23','9.41 pm','BHHC Tisha B’Av times']]) T(s,'Fast ends','Nightfall, sun 6° below horizon',end6(D(s)),a,src);
for (const [s,a,src] of [['2026-03-13','5.44 pm','BHHC website'],['2026-09-18','6.50 pm','HH sheet'],['2026-09-25','6.35 pm','HH sheet'],['2026-10-02','6.19 pm','HH sheet'],['2026-10-09','6.00 pm','HH sheet'],['2026-10-16','5.48 pm','Weekly sheet 17 Oct']]) T(s,'Friday Mincha & Kabbalat Shabbat','Same as candle lighting',clExact(D(s)),a,src);
for (const [s,a,src] of [['2026-03-14','5.30 pm','BHHC website'],['2026-09-19','6.40 pm','HH sheet (Shabbat Shuva)'],['2026-10-10','5.45 pm','HH sheet'],['2026-10-17','5.30 pm','Weekly sheet 17 Oct']]) T(s,'Shabbat Mincha','Shabbat ends − 80 min, rounded down to 5',floor5(end85(D(s))-80),a,src);
for (const [s,a,src] of [['2026-03-14','9.15 am','BHHC website'],['2026-09-19','9.30 am','HH sheet'],['2026-10-10','9.30 am','HH sheet'],['2026-10-17','9.30 am','Weekly sheet 17 Oct']]) { const g=!isBST(D(s)); T(s,'Shabbat Shacharit','9.15 am GMT / 9.30 am BST',g?555:570,a,src); }
for (const [s,a,src] of [['2026-09-14','6.45 pm','HH sheet (Fast of Gedaliah)']]) T(s,'Fast-day Mincha & Maariv','Fast ends − 65 min, rounded down to 5',floor5(end6(D(s))-65),a,src);
const toM = a => { const [t,ap]=a.split(' '); let [h,m]=t.split('.').map(Number); if(ap==='pm'&&h!==12)h+=12; return h*60+m; };
for (const b of bt) { b.diff = toM(b.act)-b.predM; delete b.predM; }
fs.writeFileSync('data.json', JSON.stringify({rows, bt}, null, 0));
console.log(rows.length, 'rows;', bt.length, 'backtests');
console.log(bt.map(b=>`${b.date} ${b.label}: pred ${b.pred} act ${b.act} diff ${b.diff}`).join('\n'));
