// Wraps scripts/page.tpl.html with the data from gen.mjs into a standalone index.html
import fs from 'fs';
const data = fs.readFileSync('data.json','utf8');
const tpl = fs.readFileSync('scripts/page.tpl.html','utf8').replace('__DATA__', data);
const i = tpl.indexOf('<div class="wrap">');
const head = '<!doctype html>\n<html lang="en-GB">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n<meta name="robots" content="noindex">\n';
fs.writeFileSync('index.html', head + tpl.slice(0,i) + '</head>\n<body>\n' + tpl.slice(i) + '\n</body>\n</html>\n');
console.log('index.html written');
